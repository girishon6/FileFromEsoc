Select Status, ID, IsAlertComplete, IsEmailSent, IsIncidentCreated from AlertStatus where FileID in ('798','796');

Select Status, ID, IsAlertComplete, IsEmailSent, IsIncidentCreated from AlertStatus where FileID='798';

ESOC_CLTPush_A5687FJ5_20210318010502_PTP_337.txt