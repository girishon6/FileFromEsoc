import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import java.nio.file.Files as Files
import java.nio.file.Paths as Paths
import java.sql.*
import groovy.sql.Sql as Sql
import com.kms.katalon.core.annotation.Keyword as Keyword
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import groovy.io.FileType as FileType

def list = []

def id = []

def status = []

def masterid = []

def fileid=[]

def filenm

def first

def last

def dir = new File('C:/Users/gkumbar/Documents/integration_file/new/')

dir.eachFileRecurse(FileType.FILES, { def file ->
        list << file
    })

list.each({ 
        filenm = it.getName()
    })

println(filenm)

/*Files.copy(Paths.get('C:/Users/gkumbar/Documents/integration_file/new/'+filenm), Paths.get(
        '//nasv0422/esocdata_dev/CLTPUSH Daily Files_Test/ALPHA/'+filenm))
*/
response = WS.sendRequest(findTestObject('RawFileService/RawFileService'))

WS.verifyResponseStatusCode(response, 200)

CustomKeywords.'sqlserver.sqlnew.connectDB'('Dbved44051', 'CLTPULLQA2')

ResultSet rs = CustomKeywords.'sqlserver.sqlnew.executeQuery'("select ID, Status from filetable where Name = '$filenm'")

while (rs.next()) {
    id += rs.getString('ID')

    status += rs.getString('Status')
}

id.each({ 
        rs = CustomKeywords.'sqlserver.sqlnew.executeQuery'("Select Status, ID, FileID, AlertCompletionDate, IsAlertComplete, IsEmailSent, IsIncidentCreated, MasterID from AlertStatus where ID = '$it'")

        while (rs.next()) {
            masterid += rs.getString('MasterID')
			fileid +=rs.getString('FileID')
        }
    })

id.each({ 
        println(it)//optional printing for my reference
    })

masterid.each({ 
        println(it)

        rs = CustomKeywords.'sqlserver.sqlnew.executeQuery'("Select ExecutionResult, MasterID, AlertID, SourceRecordCount, DestinationRecordCount from EventCountCER Where MasterID = '$it'")

        while (rs.next()) {
            masterid += rs.getString('MasterID')
			
        }
    })

/*{ 
	resultSet ->
	while (resultSet.next()) {
	   first = resultSet.getString(1)
	   last = resultSet.getString('Status')
	   expected[rowNum++] == "$first $last"
	  }
 }*/
response = WS.sendRequest(findTestObject('AlertingService/AlertingService'))

WS.verifyResponseStatusCode(response, 200)

fileid.each({
	rs=CustomKeywords.'sqlserver.sqlnew.executeQuery'("Select Status, ID, IsAlertComplete, IsEmailSent, IsIncidentCreated from AlertStatus where FileID='$it'")
	
})


CustomKeywords.'sqlserver.sqlnew.closeDatabaseConnection'()

