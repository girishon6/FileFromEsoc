Select ExecutionResult, MasterID, AlertID, SourceRecordCount, DestinationRecordCount from EventCountCER Where MasterID = '$it'

select ID, Status from filetable where Name = 'ESOC_CLTPush_A5687FJ5_20210318010502_PTP_339.txt'

Select Status, ID, FileID, AlertCompletionDate, IsAlertComplete, IsEmailSent, IsIncidentCreated, MasterID from AlertStatus where ID in ('3899','3900','3901','3902');


Select ExecutionResult, MasterID, AlertID, SourceRecordCount, DestinationRecordCount from EventCountCER Where MasterID in ('E2EOICIRR87401','E2EOICIRR87400','E2EOICISL87800','E2EOICHWY94103') and id in ('3899','3900','3901','3902') 

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'AlertStatus'
ORDER BY ORDINAL_POSITION

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'filetable'
ORDER BY ORDINAL_POSITION

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'EventCountCER'
ORDER BY ORDINAL_POSITION


